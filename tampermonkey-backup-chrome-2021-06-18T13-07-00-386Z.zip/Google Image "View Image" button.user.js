// ==UserScript==
// @name           Google Image "View Image" button
// @version        0.3.0.1
// @description    This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @description:ru Добавляет кнопку просмотра изображения.
// @author         gvvad
// @run-at         document-end
// @include        http*://www.google.*.*/*
// @include        http*://google.*.*/*
// @include        http*://www.google.*/*
// @include        http*://google.*/*
// @grant          none
// @license        MIT; https://opensource.org/licenses/MIT
// @copyright      2019, gvvad
// @namespace      https://greasyfork.org/users/100160
// ==/UserScript==
