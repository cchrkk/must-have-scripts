// ==UserScript==
// @name         Bypass paywalls for scientific documents
// @namespace    StephenP
// @version      3.3.6
// @description  Bypass paywalls for scientific documents by downloading them from sci-hub instead of paying something like 50 bucks for each paper. This script adds download buttons on Google Scholar, Scopus and Web Of Science, which lead to sci-hub.tw. In this way you can get free access to scientific papers even if you (or your university) can't afford their prices.
// @author       StephenP
// @include      http://scholar.google.*/scholar?*
// @match        http://www.scopus.com/record/display.uri?*
// @match        http://apps.webofknowledge.com/full_record.do?*
// @match        http://apps.webofknowledge.com/InterService.do?*
// @match        http://apps.webofknowledge.com/CitedFullRecord.do?*
// @include      https://scholar.google.*/scholar?*
// @match        https://www.scopus.com/record/display.uri?*
// @match        https://apps.webofknowledge.com/full_record.do?*
// @match        https://apps.webofknowledge.com/InterService.do?*
// @match        https://apps.webofknowledge.com/CitedFullRecord.do?*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    //If Sci-Hub address changes, just replace the URL below with the new one
    var sciHubUrl='https://sci-hub.se/';
    var documentId;
    var site=window.location.href.toString();
    var i;
    if(site.includes("://www.scopus.com/")){
      var fullDocument=document.createElement("LI");
      fullDocument.innerHTML="Full text from Sci-Hub";
      fullDocument.style.cursor="pointer";
      fullDocument.style.color="#ff6c00";
      documentId=document.getElementById("recordDOI").innerHTML;
      fullDocument.addEventListener('click',function(){window.open(sciHubUrl+documentId)});
      document.getElementById('quickLinks').children[0].appendChild(fullDocument);  
      var donateBtn=document.createElement("LI");
      donateBtn.innerHTML="Donate to Sci-Hub";
      donateBtn.style.cursor="pointer";
      donateBtn.addEventListener('click',function(){donate(sciHubUrl)});
      document.getElementById('quickLinks').children[0].appendChild(donateBtn);
    }
    else if(site.includes("://apps.webofknowledge.com/")){
        var mode;
        var genericID=document.getElementsByClassName("block-record-info block-record-info-source")[0].getElementsByClassName("FR_label");
      	for(i=0;i<=genericID.length;i++){
          if((genericID[i].innerHTML==="DOI:")||(genericID[i].innerHTML==="PMID:")){
            documentId=genericID[i].parentNode.children[1].innerHTML;
            console.log(documentId);
            break;
          }
        }
        if(documentId!==undefined){
            addButtonWOS(sciHubUrl,documentId);
        }
    }
    else if(site.includes("://scholar.google.")){
        var resourcesList=document.getElementById('gs_res_ccl_mid');
        var results=resourcesList.children.length;
        var gs_ggs_gs_fl;
        for(i=0;i<results;i++){
            try{
                if(resourcesList.children[i].getElementsByClassName("gs_ggs gs_fl").length==0){
                    gs_ggs_gs_fl=document.createElement("div");
                    gs_ggs_gs_fl.setAttribute("class","gs_ggs gs_fl");
                  	gs_ggs_gs_fl.appendChild(document.createElement("div"));
                  	gs_ggs_gs_fl.children[0].setAttribute("class","gs_ggsd");
                  	gs_ggs_gs_fl.children[0].appendChild(document.createElement("div"));
                  	gs_ggs_gs_fl.children[0].children[0].setAttribute("class","gs_or_ggsm");
                    resourcesList.children[i].insertBefore(gs_ggs_gs_fl,resourcesList.children[i].firstChild);
                    addButtonScholar(sciHubUrl,resourcesList.children[i].firstChild);
                }
                else{
                    addButtonScholar(sciHubUrl,resourcesList.children[i].firstChild);
                }
            }
            catch(err){
                console.error(err+"//"+resourcesList.children[i].lastElementChild.innerHTML);
            }
        }
    }
})();
function addButtonWOS(sciHubUrl,documentId){
    try{
        var site=window.location.href.toString();
        const fTBtn=document.getElementsByClassName("solo_full_text")[0];
        var sciHubBtn = fTBtn.cloneNode(true);
        var list=document.getElementsByClassName("l-columns-item")[0];
        sciHubBtn.setAttribute("alt","Break the walls and free the knowledge that publishers taken hostage\!");
        sciHubBtn.setAttribute("title","Break the walls and free the knowledge that publishers taken hostage\!");
        sciHubBtn.setAttribute("id","sciHubBtn");
        sciHubBtn.getElementsByTagName('A')[0].innerHTML="Search on Sci-Hub";
        sciHubBtn.getElementsByTagName('A')[0].removeAttribute("href");
      sciHubBtn.getElementsByTagName('A')[0].removeAttribute("onclick");
        sciHubBtn.getElementsByTagName('A')[0].addEventListener("click",function(){window.open(sciHubUrl+documentId);});
        sciHubBtn.style.cursor="pointer";
        fTBtn.children[0].style.marginLeft="0";
        sciHubBtn.style.marginRight="0";
        list.insertAdjacentHTML('beforeend','<li><a style="font-size: 12px; margin-left: 10px; color: green; text-decoration: underline;" href="javascript:;">Donate to Sci-Hub project</a></li>');
        list.lastChild.lastChild.removeAttribute("href");
        list.lastChild.lastChild.addEventListener("click", function(){donate(sciHubUrl);});
        list.lastChild.lastChild.style.cursor="pointer";
        fTBtn.parentNode.insertBefore(sciHubBtn, fTBtn);
        //list.insertBefore(sciHubBtn,list.lastChild);
    }
    catch(err){
        console.log(err);
    }
    //setAttribute('onclick',donate(sciHubUrl));
}
function addButtonScholar(sciHubUrl,linkDiv){
  //alert(linkDiv.innerHTML);
    var link;
    try{
      link=linkDiv.getElementsByTagName("A")[0].href;
    }
  	catch(err){
      link=linkDiv.parentNode.getElementsByClassName("gs_rt")[0].getElementsByTagName("A")[0].href;
		}
    if(link.includes("scholar?output")){
      link=linkDiv.parentNode.getElementsByClassName("gs_rt")[0].getElementsByTagName("A")[0].href;
    }
  	if(link!=undefined){
      var creatingElement;
      if((link!=undefined)&&(link.search("patents.google")==-1)){
        creatingElement=document.createElement("a");
        creatingElement.innerHTML='<a>Search on Sci-Hub</a>';
        linkDiv.getElementsByClassName("gs_or_ggsm")[0].appendChild(creatingElement);
        linkDiv.getElementsByClassName("gs_or_ggsm")[0].lastChild.addEventListener("click", function(){window.open(sciHubUrl+link);});
        linkDiv.getElementsByClassName("gs_or_ggsm")[0].lastChild.style.cursor="pointer";
        //setAttribute("onclick",'window.open(\"'+sciHubUrl+link+'\");');
      }
    }
  
  	document.head.innerHTML = document.head.innerHTML.replace(/13px 8px 9px 8px/g, '0px 8px 0px 8px');
}
function donate(sciHubUrl){
    window.open(sciHubUrl+'#donate');
}